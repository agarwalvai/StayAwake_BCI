package com.example.vaibhav.stayawake5;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.net.URISyntaxException;

public class MainActivity extends AppCompatActivity {

    Button click;
    public static TextView data;
    private WebSocketClient mWebSocketClient = null;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        click = (Button) findViewById(R.id.button);
        data  = (TextView) findViewById(R.id.fetcheddata);
        textView = (TextView) findViewById(R.id.messages);


        click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                fetchData process = new fetchData();
//                process.execute();
                connectWebSocket();
            }
        });
    }
    private void connectWebSocket() {
        URI uri;
        try {
            uri = new URI("wss://emotivcortex.com:54321");
        } catch (URISyntaxException e) {
            e.printStackTrace();
            return;
        }

//         mWebSocketClient = null;
        mWebSocketClient = new WebSocketClient(uri) {
            @Override
            public void onOpen(ServerHandshake serverHandshake) {
                Log.i("Websocket", "Opened");

                JSONObject createSessionJson = new JSONObject();
                JSONObject createSessionParams = new JSONObject();
                try {
                    createSessionParams.put("_auth", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBJZCI6ImNvbS52YWliaGF2My5zdGF5YXdha2UiLCJleHAiOjE1NDAyMjM2MjAsImZpcnN0TmFtZSI6IlZhaWJoYXYiLCJsYXN0TmFtZSI6IkFnYXJ3YWwiLCJsaWNlbnNlIjp7ImlzX2NvbW1lcmNpYWwiOmZhbHNlLCJsaWNlbnNlSWQiOiI0MWViNTBmNC1iMDVhLTQyNDUtOGYxNy1jNDA5NjQxZjAyMmYiLCJsaWNlbnNlU2NvcGUiOjEsImxpY2Vuc2VfZXhwaXJlIjoxODU1MDA4MDAwLCJsaWNlbnNlX2hhcmRMaW1pdCI6MTU0MzAxNzU5OSwibGljZW5zZV9zb2Z0TGltaXQiOjE1NDI0MTI3OTl9LCJsaWNlbnNlSWQiOiI0MWViNTBmNC1iMDVhLTQyNDUtOGYxNy1jNDA5NjQxZjAyMmYiLCJsaWNlbnNlU2NvcGUiOjEsImxpY2Vuc2VfYWdyZWVtZW50Ijp7ImFjY2VwdGVkIjp0cnVlLCJsaWNlbnNlX3VybCI6Imh0dHBzOi8vd3d3LmVtb3RpdmNsb3VkLmNvbS9kYmFwaS9wcml2YWN5L2RvYy9ldWxhLyJ9LCJsaWNlbnNlX2V4cGlyZSI6MTg1NTAwODAwMCwibGljZW5zZV9oYXJkTGltaXQiOjE1NDMwMTc1OTksImxpY2Vuc2Vfc29mdExpbWl0IjoxNTQyNDEyNzk5LCJuYmYiOjE1Mzk5NjQ0MjAsInVzZXJDbG91ZElkIjo0Nzg4MCwidXNlcm5hbWUiOiJmb3J0X25pdGUifQ.ul2H4QtI4eH09uuYTWWdbCjL51TMsR4qc8KD5ZfxWcA");
                    createSessionParams.put("status", "open");
                    createSessionJson.put("jsonrpc", "2.0");
                    createSessionJson.put("method", "createSession");
                    createSessionJson.put("params", createSessionParams);
                    createSessionJson.put("id", 1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String obj_string = createSessionJson.toString();
                mWebSocketClient.send(obj_string);

//                try {
//                    Thread.sleep(2000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }

//                JSONObject json = new JSONObject();
//                JSONObject params = new JSONObject();
//                try {
//                    params.put("_auth", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBJZCI6ImNvbS52YWliaGF2My5zdGF5YXdha2UiLCJleHAiOjE1NDAyMjM2MjAsImZpcnN0TmFtZSI6IlZhaWJoYXYiLCJsYXN0TmFtZSI6IkFnYXJ3YWwiLCJsaWNlbnNlIjp7ImlzX2NvbW1lcmNpYWwiOmZhbHNlLCJsaWNlbnNlSWQiOiI0MWViNTBmNC1iMDVhLTQyNDUtOGYxNy1jNDA5NjQxZjAyMmYiLCJsaWNlbnNlU2NvcGUiOjEsImxpY2Vuc2VfZXhwaXJlIjoxODU1MDA4MDAwLCJsaWNlbnNlX2hhcmRMaW1pdCI6MTU0MzAxNzU5OSwibGljZW5zZV9zb2Z0TGltaXQiOjE1NDI0MTI3OTl9LCJsaWNlbnNlSWQiOiI0MWViNTBmNC1iMDVhLTQyNDUtOGYxNy1jNDA5NjQxZjAyMmYiLCJsaWNlbnNlU2NvcGUiOjEsImxpY2Vuc2VfYWdyZWVtZW50Ijp7ImFjY2VwdGVkIjp0cnVlLCJsaWNlbnNlX3VybCI6Imh0dHBzOi8vd3d3LmVtb3RpdmNsb3VkLmNvbS9kYmFwaS9wcml2YWN5L2RvYy9ldWxhLyJ9LCJsaWNlbnNlX2V4cGlyZSI6MTg1NTAwODAwMCwibGljZW5zZV9oYXJkTGltaXQiOjE1NDMwMTc1OTksImxpY2Vuc2Vfc29mdExpbWl0IjoxNTQyNDEyNzk5LCJuYmYiOjE1Mzk5NjQ0MjAsInVzZXJDbG91ZElkIjo0Nzg4MCwidXNlcm5hbWUiOiJmb3J0X25pdGUifQ.ul2H4QtI4eH09uuYTWWdbCjL51TMsR4qc8KD5ZfxWcA");
//                    params.put("streams", new String[]{"met"});
//                    json.put("jsonrpc", "2.0");
//                    json.put("method", "subscribe");
//                    json.put("params",params);
//                    json.put("id", 1);
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }

//                obj_string = json.toString();
//                mWebSocketClient.send(obj_string);
            }

            @Override
            public void onMessage(String s) {
                final String message;
                message = s;
                Log.d("MESSAGE", message);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textView.setText(textView.getText() + "\n" + message);
                    }
                });
            }

            @Override
            public void onClose(int i, String s, boolean b) {
                Log.i("Websocket", "Closed " + s);
            }

            @Override
            public void onError(Exception e) {
                Log.i("Websocket", "Error " + e.getMessage());
            }
        };
        mWebSocketClient.connect();
    }
}
